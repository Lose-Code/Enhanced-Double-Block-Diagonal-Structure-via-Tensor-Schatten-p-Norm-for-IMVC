function y = normr(x)
% Row normalization, retaining the original uniform-vector rule for zero rows.
if isempty(x)
    y = x;
    return;
end
x(~isfinite(x)) = 0;
row_norm = sqrt(sum(abs(x).^2, 2));
y = bsxfun(@rdivide, x, row_norm);
zero_rows = row_norm == 0;
y(zero_rows, :) = 1 / sqrt(size(x, 2));
end
