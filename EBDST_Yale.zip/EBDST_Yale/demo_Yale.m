function [Result, details] = demo_Yale
% Requires MATLAB and Statistics and Machine Learning Toolbox (kmeans).
root = fileparts(mfilename('fullpath'));
original_path = path;
cleanup_path = onCleanup(@() path(original_path));
addpath(fullfile(root, 'functions'));
assert(exist('kmeans', 'file') == 2, ...
    'Statistics and Machine Learning Toolbox is required for kmeans.');

data = load(fullfile(root, 'data', 'yaleA_3view.mat'), 'X', 'Y');
X = data.X;
gnd = data.Y(:);
n = numel(gnd);
nv = numel(X);
K = numel(unique(gnd));
assert(isequal(unique(gnd), (1:K)'), 'Labels must be consecutive integers starting at 1.');
data_views = cell(1, nv);
class_labels = zeros(1, K);
for v = 1:nv
    data_views{v} = X{v}';
end
for c = 1:K
    class_labels(c) = sum(gnd == c);
end

missing_rates = [0.1, 0.3, 0.5];
parameters = [0.05, 0.005, 0.7; 0.1, 0.001, 1.0; 0.05, 0.005, 1.0];
num_neighbors = 5;
repeated_times = 10;
Result = cell(1, numel(missing_rates));
details = struct([]);

for r = 1:numel(missing_rates)
    stream = RandStream.getGlobalStream;
    reset(stream);
    rand('state', 100);
    observed_count = floor(n * (1 - missing_rates(r)));
    Mn = cell(1, nv);
    for v = 1:nv
        pos = randperm(n);
        Mn{v} = zeros(1, n);
        Mn{v}(pos(1:observed_count)) = 1;
    end

    [L_views, H_views, ~] = data_preprocess_sefl(data_views, Mn, num_neighbors, K);
    alpha = parameters(r, 1);
    beta = parameters(r, 2);
    p = parameters(r, 3);
    solver_clock = tic;
    [F, iterations, obj_values] = utgl_sefl(L_views, H_views, alpha, beta, p);
    solver_seconds = toc(solver_clock);

    metrics = zeros(repeated_times, 6);
    predicted_labels = zeros(n, repeated_times);
    for rep = 1:repeated_times
        labels = kmeans(F, K, 'MaxIter', 1000, 'Replicates', 20, ...
            'EmptyAction', 'singleton');
        predicted_labels(:, rep) = labels;
        acc = accuracy(gnd, labels);
        cluster_data = cell(1, K);
        for c = 1:K
            cluster_data{c} = gnd(labels == c)';
        end
        [nmi, purity, fmeasure, ri, ari] = calculate_results(class_labels, cluster_data);
        metrics(rep, :) = [acc, nmi, purity, fmeasure, ri, ari];
    end

    avg = mean(metrics, 1);
    sd = std(metrics, 0, 1);
    Result{r} = [alpha, beta, p, avg, sd, solver_seconds];
    details(r).missing_rate = missing_rates(r);
    details(r).parameters = parameters(r, :);
    details(r).mask = cell2mat(Mn')';
    details(r).embedding = F;
    details(r).labels = predicted_labels;
    details(r).metrics = metrics;
    details(r).iterations = iterations;
    details(r).residuals = obj_values(1:iterations);

    fprintf('\nYale | missing rate %.1f | alpha %.4g | beta %.4g | p %.1f\n', ...
        missing_rates(r), alpha, beta, p);
    fprintf('ACC: %.2f +/- %.2f | NMI: %.2f +/- %.2f | PUR: %.2f +/- %.2f | F-score: %.2f +/- %.2f\n', ...
        avg(1), sd(1), 100*avg(2), 100*sd(2), ...
        100*avg(3), 100*sd(3), 100*avg(4), 100*sd(4));
    fprintf('Solver time: %.4f s | iterations: %d\n', solver_seconds, iterations);
end
end
